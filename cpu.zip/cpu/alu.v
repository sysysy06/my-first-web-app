`include "defines.h"

module alu (
  output reg [15:0] q,
  input [15:0] sr1,
  input [15:0] sr2,
  input [15:0] pc,
  input [15:0] ir,
  input [3:0] ph,
  input CLK,
  input RSTN
  );
  
  wire [15:0] immu4 = {12'b0,ir[3:0]};      // unsigned 4-bit immediate operand
  wire [15:0] imms8 = {{8{ir[7]}},ir[7:0]}; // signed 8-bit immediate operand
  
  always @(posedge CLK or negedge RSTN)
  begin
    if (!RSTN)
    begin
      q <= 0;
    end
    else
    begin
      casex ({ph,ir})
      {`PH2,`ADD}: q <= sr1 + sr2;
      {`PH2,`B}:   q <= pc + imms8;
      {`PH2,`BNZ}: if (sr1==0)
                     q <= pc+3;
                   else
                     q <= pc + imms8;
      {`PH2,`BZ}: if (sr1!=0)
                     q <= pc+3;
                   else
                     q <= pc + imms8;
      {`PH2,`SGT}:  if (sr1>sr2)
                     q <= 16'hFFFF;
                   else
                     q <= 0000;
      {`PH2,`MLT}:  q <= sr1*sr2;
      {`PH2,`LI}:  q <= imms8;
      endcase
    end
  end
endmodule
