# "ldstbnz.s" Last updated: March 27, 2026

# Part 1: Fill all addresses with "1"s
      LI    r1, 0
      LI    r2, 1
      LI    r3, 1
      LI    r4, -101
LP1:  ST    (r1), r2
      ADD   r1, r1, r3
      ADD   r5, r1, r4
      BNZ   r5, LP1:

# Part 2: Write "0" only to even addresses
      LI    r1, 0
      LI    r2, 0
      LI    r3, 2
      LI    r4, -102
LP2:  ST    (r1), r2
      ADD   r1, r1, r3
      ADD   r5, r1, r4
      BNZ   r5, LP2:

# Part 3: Write "0" only to addresses that are multiples of 3
      LI    r1, 0
      LI    r2, 0
      LI    r3, 3
      LI    r4, -102
LP3:  ST    (r1), r2
      ADD   r1, r1, r3
      ADD   r5, r1, r4
      BNZ   r5, LP3:

# Part 4: Count the number of "1"s in memory
      LI    r0, 0
      LI    r1, 0
      LI    r3, 1
      LI    r4, -101
LP4:  LD    r2, (r1)
      ADD   r0, r0, r2
      ADD   r1, r1, r3
      ADD   r5, r1, r4
      BNZ   r5, LP4:

# Part 5: Enter an infinite loop to prevent runaway execution
HLT:  B     HLT:
