`define PH0 4'bxxx1
`define PH1 4'bxx1x
`define PH2 4'bx1xx
`define PH3 4'b1xxx

`define NOP  16'b00_000_000_000_0_0000
`define ADD  16'b00_xxx_xxx_xxx_0_0001
`define SGT  16'b00_xxx_xxx_xxx_0_0010
`define MLT  16'b00_xxx_xxx_xxx_0_0011
`define ADDI 16'b00_xxx_xxx_000_1_xxxx
`define SUBI 16'b00_xxx_xxx_001_1_xxxx
`define LD   16'b00_xxx_xxx_100_1_xxxx
`define ST   16'b01_000_xxx_xxx_0_xxxx
`define B    16'b01_100_000_xxxxxxxx
`define BNZ  16'b01_101_xxx_xxxxxxxx
`define BZ   16'b01_110_xxx_xxxxxxxx
`define LI   16'b10_xxx_000_xxxxxxxx
