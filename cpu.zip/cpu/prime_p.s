      LI    r0,100      # n
      LI    r1,2        # i = 2
      LI    r2,1        # 1
      LI    r3,10        # 10
# Part 1: s[2]〜s[101] を1で初期化

LP1:  ST    1(r1), r2
      ST    3(r1), r2
      ST    5(r1), r2
      ST    7(r1), r2
      ST    9(r1), r2
      ADD   r1, r1, r3
      SGT   r5, r1, r0
      BZ    r5, LP1:
      NOP
      NOP
      NOP
# Part 2: 
      LI    r6, 3        # k=3
      LI    r7, 0        # 0

DOWH:
      MLT   r1,r6,r6
      SGT   r5,r1,r0	 # k*k<n
      BNZ   r5,COUNT:    # 篩が終わったら数える処理へ
      NOP
      NOP
      NOP

      LD    r5,0(r6)
      BZ    r5,ENDIF:
      NOP
      NOP
      NOP

LP2:  ST    (r1), r7
      ADD   r5,r6,r6     # r5 = 2k
      ADD   r1,r1,r5     # j += 2k
      SGT   r5,r1,r0
      BZ    r5, LP2:
      NOP
      NOP
      NOP

ENDIF:
      LI    r5,2
      ADD   r6,r6,r5
      B     DOWH:
      NOP
      NOP
      NOP

# Part 3: 素数の数を数える
COUNT:
      LI    r4,1         # 2を先に数える
      LI    r6,3         # i=3

COUNTLP:
      LD    r5,0(r6)     # s[i]
      BZ    r5,COUNTSKIP:
      NOP
      NOP
      NOP

      ADD   r4,r4,r2     # s[i] == 1 なら素数数++

COUNTSKIP:
      ADD   r6,r6,r2
      ADD   r6,r6,r2     # i += 2
      SGT   r5,r6,r0
      BZ    r5,COUNTLP:
      NOP
      NOP
      NOP

HLT:  B     HLT:
      NOP
      NOP
      NOP
