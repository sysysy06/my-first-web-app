

      	LI    r1, 2     #i=2
     	LI    r2, 0     
      	LI    r3, 1     
      	LI    r4, 100
LP1:  	ST    (r1), r3	#s[i]=1
	ADD   r1, r1, r3	#i++
      	SGT   r5, r1, r4	#i<=nならループ(i>nではないならループ)
      	BZ    r5, LP1:

	
      	LI    r6, 0	#j=0
      	LI    r7, 2	#k=2
DOWH:  	LD    r0, (r7)
	BZ    r0, ENDIF:	#if(s[k]!=0)
      	ADD   r6, r6, r3	#j++
      	MLT   r1, r7, r7  #k*k

LP2:  	ST    (r1), r2	#s[i]=0
      	ADD   r1, r1, r7	#i+=k
      	SGT   r5, r1, r4	#i<=nならループ(i>nではないならループ)
      	BZ    r5, LP2:

ENDIF:  ADD   r7, r7, r3	#k++
      	SGT   r5, r7, r4	#k<=nならループ(k>nではないならループ)
      	BZ    r5, DOWH:		
      	


# Part 5: Enter an infinite loop to prevent runaway execution
HLT:  B     HLT:
