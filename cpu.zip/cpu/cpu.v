`include "defines.h"

module cpu (
  output [15:0] imem_addr,
  input  [15:0] imem_rdata,
  output [15:0] dmem_addr,
  input  [15:0] dmem_rdata,
  output [15:0] dmem_wdata,
  output reg    dmem_write,
  output [127:0] led_reg,
  output [127:0] led_misc,
  output [3:0]   led_ph,
  input         start,
  input         stop,
  input         CLK,
  input         RSTN
  );
  
  wire [3:0] ph;
  wire [15:0] w_pc, w_ir, w_sr1, w_sr2,w_alu, w_dr,w_pcp0,w_pcp1,w_irp0,w_irp1,w_irp2,w_irp3;
  wire [15:0] r0, r1, r2, r3, r4, r5, r6, r7,regfile_wdatap3;
  reg [15:0] regfile_wdata,w_sr1fw,w_sr2fw;
  reg pc_write, dr_write, regfile_write;
  
  
    always @*
  begin
  	casex (w_irp2)
 	 `B,
 	 `BNZ,
 	 `ST,
 	 `NOP,
 	 `BZ:
 	 	w_sr1fw = w_sr1;
 	 default:begin
		if (w_irp2[13:11] == w_irp1[10:8])
		   w_sr1fw = regfile_wdata;
		else begin
  		casex (w_irp3)
 		 `B,
 		 `BNZ,
 		 `ST,
 	         `NOP,
 		 `BZ:
 	 		w_sr1fw = w_sr1;
 	 	default:begin
		 if(w_irp3[13:11] == w_irp1[10:8])
		    w_sr1fw = regfile_wdatap3;
		 else
		    w_sr1fw = w_sr1;
		    end
		endcase
		end
		
	    end
	endcase
  end

//fowarding sr2
   always @*
  begin
  	casex (w_irp2)
 	 `B,
 	 `BNZ,
 	 `ST,
 	 `NOP,
 	 `BZ:
 	 	w_sr2fw = w_sr2;
 	 default:begin
		if (w_irp2[13:11] == w_irp1[7:5])
		   w_sr2fw = regfile_wdata;
		else begin
  		casex (w_irp3)
 		 `B,
 		 `BNZ,
 		 `ST,
 	         `NOP,
 		 `BZ:
 	 		w_sr2fw = w_sr2;
 	 	default:begin
		 if(w_irp3[13:11] == w_irp1[7:5])
		    w_sr2fw = regfile_wdatap3;
		 else
		    w_sr2fw = w_sr2;
		    end
		endcase
		end
	    end
	endcase
  end
  
  // imem_addr
  assign imem_addr = w_pc;
  
  // dmem_addr
  assign dmem_addr = w_sr1fw + w_irp1[3:0];
  
  // dmem_wdata
  assign dmem_wdata = w_sr2fw;

  // led_reg, led_misc, led_ph
  assign led_reg  = {r7,r6,r5,r4,r3,r2,r1,r0};
  assign led_misc = {16'd0,16'd0,w_dr,w_alu,w_sr2,w_sr1,w_ir,w_pc};
  assign led_ph   = ph;

  // pc_write
  always @*
  begin
    casex ({ph,w_irp2})
    {`PH3,`B}:   pc_write = 1'b1; // B
    {`PH3,`BNZ}: pc_write = 1'b1; // BNZ
    {`PH3,`BZ}: pc_write = 1'b1; 
    default:     pc_write = 1'b0;
    endcase
  end

  // regfile_write
  always @*
  begin
    casex ({ph,w_irp2})
    {`PH3,`LD}: regfile_write = 1'b1;
    {`PH3,`ADD}: regfile_write = 1'b1;
    {`PH3,`LI}: regfile_write = 1'b1;
    {`PH3,`SGT}: regfile_write = 1'b1;
    {`PH3,`MLT}: regfile_write = 1'b1;
    
    
    default:     regfile_write = 1'b0;
    endcase
  end

  // dmem_write
  always @*
  begin
    casex ({ph,w_irp1})
    {`PH2,`ST}: dmem_write = 1'b1;
    default:    dmem_write = 1'b0;
    endcase
  end

  // dr_write
  always @*
  begin
    casex ({ph,w_irp1})
    {`PH2,`LD}: dr_write = 1'b1;
    default:    dr_write = 1'b0;
    endcase
  end

  // regfile_wdata
  always @*
  begin
    casex (w_irp2)
    `LD:     regfile_wdata = w_dr;
    default: regfile_wdata = w_alu;
    endcase
  end

  sm sm (
    .q(ph), 
    .start(start),
    .stop(stop),
    .CLK(CLK), 
    .RSTN(RSTN)
  );

  count16rle pc (
    .q(w_pc),
    .load(pc_write),
    .inc(ph[0]),
    .d(w_alu),
    .CLK(CLK),
    .RSTN(RSTN)
  );

  reg16 ir (
    .q(w_ir),
    .load(ph[0]),
    .d(imem_rdata),
    .CLK(CLK),
    .RSTN(RSTN)
  );
  reg16 pcp0 (
  .q(w_pcp0),
  .load(ph[0]),
  .d(w_pc),
  .CLK(CLK),
  .RSTN(RSTN)

);

reg16 pcp1 (
  .q(w_pcp1),
  .load(ph[1]),
  .d(w_pcp0),
  .CLK(CLK),
  .RSTN(RSTN)
);

reg16 irp1 (
  .q(w_irp1),
  .load(ph[1]),
  .d(w_ir),
  .CLK(CLK),
  .RSTN(RSTN)
);

reg16 irp2 (
  .q(w_irp2),
  .load(ph[2]),
  .d(w_irp1),
  .CLK(CLK),
  .RSTN(RSTN)
);

reg16 irp3 (
  .q(w_irp3),
  .load(ph[3]),
  .d(w_irp2),
  .CLK(CLK),
  .RSTN(RSTN)
);

  reg16 postp3reg (
    .q(regfile_wdatap3),
    .load(ph[3]),
    .d(regfile_wdata),
    .CLK(CLK),
    .RSTN(RSTN)
  );


  regfile regfile (
    .q0(r0),
    .q1(r1),
    .q2(r2),
    .q3(r3),
    .q4(r4),
    .q5(r5),
    .q6(r6),
    .q7(r7),
    .load(regfile_write),
    .wsel(w_irp2[13:11]),
    .d(regfile_wdata),
    .CLK(CLK),
    .RSTN(RSTN)
  );

  muxreg16 sr1 (
    .q(w_sr1),
    .load(ph[1]),
    .d0(r0),
    .d1(r1),
    .d2(r2),
    .d3(r3),
    .d4(r4),
    .d5(r5),
    .d6(r6),
    .d7(r7),
    .sel(w_ir[10:8]),
    .CLK(CLK),
    .RSTN(RSTN)
  );

  muxreg16 sr2 (
    .q(w_sr2),
    .load(ph[1]),
    .d0(r0),
    .d1(r1),
    .d2(r2),
    .d3(r3),
    .d4(r4),
    .d5(r5),
    .d6(r6),
    .d7(r7),
    .sel(w_ir[7:5]),
    .CLK(CLK),
    .RSTN(RSTN)
  );

  alu alu (
    .q(w_alu),
    .sr1(w_sr1fw),
    .sr2(w_sr2fw),
    .pc(w_pcp0),
    .ir(w_irp1),
    .ph(ph),
    .CLK(CLK),
    .RSTN(RSTN)
  );

  reg16 dr (
    .q(w_dr),
    .load(dr_write),
    .d(dmem_rdata),
    .CLK(CLK),
    .RSTN(RSTN)
  );

endmodule
